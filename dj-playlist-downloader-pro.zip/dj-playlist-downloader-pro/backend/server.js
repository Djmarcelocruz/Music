/**
 * DJ Playlist Downloader PRO - Servidor Principal
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const path = require('path');
const fs = require('fs');

const { initializeDatabase } = require('./database/init');
const { logger } = require('./utils/logger');
const { errorHandler } = require('./utils/errorHandler');

const tracksRoutes = require('./routes/tracks');
const playlistsRoutes = require('./routes/playlists');
const favoritesRoutes = require('./routes/favorites');
const historyRoutes = require('./routes/history');
const settingsRoutes = require('./routes/settings');

const app = express();
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

function configureMiddlewares() {
    app.use(helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
                scriptSrc: ["'self'", "'unsafe-inline'"],
                fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
                imgSrc: ["'self'", "data:", "https:", "blob:"],
                mediaSrc: ["'self'", "blob:"],
                connectSrc: ["'self'"]
            }
        }
    }));

    app.use(cors({
        origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization']
    }));

    app.use(compression());
    app.use(morgan(NODE_ENV === 'development' ? 'dev' : 'combined', {
        stream: { write: (message) => logger.info(message.trim()) }
    }));

    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true, limit: '10mb' }));
}

function configureRoutes() {
    app.get('/api/health', (req, res) => {
        res.json({ status: 'ok', version: '1.0.0', environment: NODE_ENV, timestamp: new Date().toISOString() });
    });

    app.use('/api/tracks', tracksRoutes);
    app.use('/api/playlists', playlistsRoutes);
    app.use('/api/favorites', favoritesRoutes);
    app.use('/api/history', historyRoutes);
    app.use('/api/settings', settingsRoutes);

    app.use(express.static(path.join(__dirname, '../frontend')));

    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, '../frontend/index.html'));
    });
}

async function startServer() {
    try {
        const downloadDir = process.env.DOWNLOAD_DIR || './downloads';
        if (!fs.existsSync(downloadDir)) {
            fs.mkdirSync(downloadDir, { recursive: true });
        }

        const db = initializeDatabase();
        app.locals.db = db;

        configureMiddlewares();
        configureRoutes();
        app.use(errorHandler);

        app.listen(PORT, () => {
            logger.info(`DJ Playlist Downloader PRO rodando na porta ${PORT}`);
            logger.info(`Ambiente: ${NODE_ENV}`);
            logger.info(`URL: http://localhost:${PORT}`);
        });

    } catch (error) {
        logger.error('Falha ao iniciar servidor:', error);
        process.exit(1);
    }
}

process.on('uncaughtException', (err) => {
    logger.error('Excecao nao capturada:', err);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error('Rejeicao nao tratada:', { reason, promise });
});

startServer();
