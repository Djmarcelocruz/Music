/**
 * Inicializacao do banco de dados SQLite
 */

const Database = require('better-sqlite3');
const path = require('path');
const { logger } = require('../utils/logger');

const DB_PATH = process.env.DB_PATH || './backend/database/djpro.db';

function initializeDatabase() {
    try {
        const db = new Database(DB_PATH);
        db.pragma('journal_mode = WAL');
        db.pragma('foreign_keys = ON');
        createTables(db);
        logger.info('Banco de dados inicializado com sucesso');
        return db;
    } catch (error) {
        logger.error('Erro ao inicializar banco de dados:', error);
        throw error;
    }
}

function createTables(db) {
    db.exec(`
        CREATE TABLE IF NOT EXISTS tracks (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            album TEXT,
            duration INTEGER DEFAULT 0,
            cover_url TEXT,
            file_path TEXT,
            bpm INTEGER,
            key TEXT,
            genre TEXT,
            category TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS playlists (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            cover_url TEXT,
            track_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS playlist_tracks (
            playlist_id TEXT NOT NULL,
            track_id TEXT NOT NULL,
            position INTEGER DEFAULT 0,
            added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (playlist_id, track_id),
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
            FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS favorites (
            track_id TEXT PRIMARY KEY,
            added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            track_id TEXT NOT NULL,
            played_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (track_id) REFERENCES tracks(id) ON DELETE CASCADE
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`
        CREATE TABLE IF NOT EXISTS categories (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL UNIQUE,
            color TEXT DEFAULT '#1DB954',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.exec(`CREATE INDEX IF NOT EXISTS idx_tracks_artist ON tracks(artist)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_tracks_album ON tracks(album)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_tracks_genre ON tracks(genre)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_tracks_category ON tracks(category)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_history_played_at ON history(played_at)`);
    db.exec(`CREATE INDEX IF NOT EXISTS idx_playlist_tracks_playlist ON playlist_tracks(playlist_id)`);

    insertDefaultSettings(db);
}

function insertDefaultSettings(db) {
    const defaults = [
        { key: 'theme', value: 'dark' },
        { key: 'language', value: 'pt-BR' },
        { key: 'download_folder', value: './downloads' },
        { key: 'default_volume', value: '80' },
        { key: 'auto_organize', value: 'true' },
        { key: 'notifications', value: 'true' }
    ];

    const stmt = db.prepare(`INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)`);
    for (const s of defaults) {
        stmt.run(s.key, s.value);
    }
}

module.exports = { initializeDatabase };
