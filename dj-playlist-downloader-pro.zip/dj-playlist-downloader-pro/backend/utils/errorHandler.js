/**
 * Tratamento centralizado de erros
 */

const { logger } = require('./logger');

class AppError extends Error {
    constructor(message, statusCode = 500, code = 'INTERNAL_ERROR') {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.isOperational = true;
        Error.captureStackTrace(this, this.constructor);
    }
}

function errorHandler(err, req, res, next) {
    logger.error('Erro na requisicao', {
        path: req.path,
        method: req.method,
        error: err.message,
        stack: err.stack
    });

    if (err instanceof AppError) {
        return res.status(err.statusCode).json({
            success: false,
            error: { message: err.message, code: err.code }
        });
    }

    if (err.message && err.message.includes('SQLITE_CONSTRAINT')) {
        return res.status(409).json({
            success: false,
            error: { message: 'Registro duplicado ou violacao de constraint', code: 'DUPLICATE_ENTRY' }
        });
    }

    res.status(500).json({
        success: false,
        error: {
            message: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor' : err.message,
            code: 'INTERNAL_ERROR'
        }
    });
}

function asyncHandler(fn) {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}

module.exports = { AppError, errorHandler, asyncHandler };
