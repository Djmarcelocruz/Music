/**
 * Sistema de logging centralizado
 */

const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(process.cwd(), 'logs');
const LOG_FILE = path.join(LOG_DIR, `djpro-${new Date().toISOString().split('T')[0]}.log`);

if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
}

function writeLog(level, message, meta = null) {
    const timestamp = new Date().toISOString();
    const metaStr = meta ? `\n${JSON.stringify(meta, null, 2)}` : '';
    const logEntry = `[${timestamp}] [${level}] ${message}${metaStr}\n`;

    const colors = {
        INFO: '\x1b[32m',
        ERROR: '\x1b[31m',
        WARN: '\x1b[33m',
        DEBUG: '\x1b[36m'
    };
    const reset = '\x1b[0m';
    console.log(`${colors[level] || ''}[${level}]${reset} ${message}`);
    if (meta && level === 'ERROR') console.error(meta);

    fs.appendFileSync(LOG_FILE, logEntry);
}

const logger = {
    info: (msg, meta) => writeLog('INFO', msg, meta),
    error: (msg, meta) => writeLog('ERROR', msg, meta),
    warn: (msg, meta) => writeLog('WARN', msg, meta),
    debug: (msg, meta) => writeLog('DEBUG', msg, meta)
};

module.exports = { logger };
