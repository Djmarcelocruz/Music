/**
 * Validacoes reutilizaveis
 */

const { AppError } = require('./errorHandler');

function validateRequired(value, fieldName) {
    if (!value || (typeof value === 'string' && value.trim().length === 0)) {
        throw new AppError(`${fieldName} e obrigatorio`, 400, 'VALIDATION_ERROR');
    }
    return value.trim();
}

function validateDuration(duration) {
    const num = Number(duration);
    if (isNaN(num) || num < 0 || num > 7200) {
        throw new AppError('Duracao invalida (max. 2 horas)', 400, 'VALIDATION_ERROR');
    }
    return num;
}

function sanitizeString(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
}

function validatePagination(page, limit) {
    const p = Math.max(1, parseInt(page) || 1);
    const l = Math.min(100, Math.max(1, parseInt(limit) || 20));
    return { page: p, limit: l, offset: (p - 1) * l };
}

module.exports = { validateRequired, validateDuration, sanitizeString, validatePagination };
