/**
 * Rotas de faixas/musicas
 */

const express = require('express');
const router = express.Router();
const { searchTracks, getTrackById, createTrack, updateTrack, deleteTrack, getLibraryStats } = require('../controllers/trackController');

router.get('/search', searchTracks);
router.get('/stats', getLibraryStats);
router.get('/:id', getTrackById);
router.post('/', createTrack);
router.put('/:id', updateTrack);
router.delete('/:id', deleteTrack);

module.exports = router;
