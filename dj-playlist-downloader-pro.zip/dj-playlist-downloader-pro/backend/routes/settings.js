/**
 * Rotas de configuracoes
 */

const express = require('express');
const router = express.Router();
const { getSettings, updateSetting, updateMultipleSettings } = require('../controllers/settingsController');

router.get('/', getSettings);
router.put('/', updateSetting);
router.put('/bulk', updateMultipleSettings);

module.exports = router;
