/**
 * Rotas de playlists
 */

const express = require('express');
const router = express.Router();
const { getPlaylists, getPlaylistById, createPlaylist, addTrackToPlaylist, removeTrackFromPlaylist, deletePlaylist } = require('../controllers/playlistController');

router.get('/', getPlaylists);
router.post('/', createPlaylist);
router.get('/:id', getPlaylistById);
router.post('/:id/tracks', addTrackToPlaylist);
router.delete('/:id/tracks/:trackId', removeTrackFromPlaylist);
router.delete('/:id', deletePlaylist);

module.exports = router;
