/**
 * Rotas de historico
 */

const express = require('express');
const router = express.Router();
const { addToHistory, getHistory, clearHistory } = require('../controllers/historyController');

router.get('/', getHistory);
router.post('/', addToHistory);
router.delete('/', clearHistory);

module.exports = router;
