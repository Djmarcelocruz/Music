/**
 * Controller de playlists
 */

const { v4: uuidv4 } = require('uuid');
const { logger } = require('../utils/logger');
const { AppError, asyncHandler } = require('../utils/errorHandler');
const { validateRequired, validatePagination } = require('../utils/validators');

const getPlaylists = asyncHandler(async (req, res) => {
    const { page, limit, offset } = validatePagination(req.query.page, req.query.limit);
    const db = req.app.locals.db;
    const total = db.prepare('SELECT COUNT(*) as total FROM playlists').get().total;
    const playlists = db.prepare(`
        SELECT p.*, COUNT(pt.track_id) as track_count
        FROM playlists p
        LEFT JOIN playlist_tracks pt ON p.id = pt.playlist_id
        GROUP BY p.id
        ORDER BY p.updated_at DESC
        LIMIT ? OFFSET ?
    `).all(limit, offset);
    res.json({ success: true, data: playlists, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
});

const getPlaylistById = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const db = req.app.locals.db;
    const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(id);
    if (!playlist) throw new AppError('Playlist nao encontrada', 404, 'NOT_FOUND');
    const tracks = db.prepare(`
        SELECT t.*, pt.position
        FROM tracks t
        JOIN playlist_tracks pt ON t.id = pt.track_id
        WHERE pt.playlist_id = ?
        ORDER BY pt.position
    `).all(id);
    res.json({ success: true, data: { ...playlist, tracks } });
});

const createPlaylist = asyncHandler(async (req, res) => {
    const { name, description, cover_url } = req.body;
    const db = req.app.locals.db;
    const playlist = {
        id: uuidv4(),
        name: validateRequired(name, 'Nome'),
        description: description || '',
        cover_url: cover_url || null
    };
    db.prepare('INSERT INTO playlists (id, name, description, cover_url) VALUES (@id, @name, @description, @cover_url)').run(playlist);
    logger.info(`Playlist criada: ${playlist.name}`);
    res.status(201).json({ success: true, data: playlist, message: 'Playlist criada com sucesso' });
});

const addTrackToPlaylist = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { track_id } = req.body;
    const db = req.app.locals.db;

    if (!db.prepare('SELECT id FROM playlists WHERE id = ?').get(id)) {
        throw new AppError('Playlist nao encontrada', 404, 'NOT_FOUND');
    }
    if (!db.prepare('SELECT id FROM tracks WHERE id = ?').get(track_id)) {
        throw new AppError('Musica nao encontrada', 404, 'NOT_FOUND');
    }

    const maxPos = db.prepare('SELECT COALESCE(MAX(position), 0) as max_pos FROM playlist_tracks WHERE playlist_id = ?').get(id);
    db.prepare('INSERT OR IGNORE INTO playlist_tracks (playlist_id, track_id, position) VALUES (?, ?, ?)').run(id, track_id, maxPos.max_pos + 1);
    db.prepare('UPDATE playlists SET track_count = (SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = ?), updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(id, id);
    logger.info(`Track ${track_id} adicionada a playlist ${id}`);
    res.json({ success: true, message: 'Musica adicionada a playlist' });
});

const removeTrackFromPlaylist = asyncHandler(async (req, res) => {
    const { id, trackId } = req.params;
    const db = req.app.locals.db;
    db.prepare('DELETE FROM playlist_tracks WHERE playlist_id = ? AND track_id = ?').run(id, trackId);
    db.prepare(`UPDATE playlist_tracks SET position = (SELECT COUNT(*) FROM playlist_tracks pt2 WHERE pt2.playlist_id = playlist_tracks.playlist_id AND pt2.rowid <= playlist_tracks.rowid) WHERE playlist_id = ?`).run(id);
    db.prepare('UPDATE playlists SET track_count = (SELECT COUNT(*) FROM playlist_tracks WHERE playlist_id = ?), updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(id, id);
    res.json({ success: true, message: 'Musica removida da playlist' });
});

const deletePlaylist = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const db = req.app.locals.db;
    const result = db.prepare('DELETE FROM playlists WHERE id = ?').run(id);
    if (result.changes === 0) throw new AppError('Playlist nao encontrada', 404, 'NOT_FOUND');
    logger.info(`Playlist removida: ${id}`);
    res.json({ success: true, message: 'Playlist removida com sucesso' });
});

module.exports = { getPlaylists, getPlaylistById, createPlaylist, addTrackToPlaylist, removeTrackFromPlaylist, deletePlaylist };
