/**
 * Controller de configuracoes
 */

const { logger } = require('../utils/logger');
const { asyncHandler } = require('../utils/errorHandler');

const getSettings = asyncHandler(async (req, res) => {
    const db = req.app.locals.db;
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsMap = settings.reduce((acc, s) => { acc[s.key] = s.value; return acc; }, {});
    res.json({ success: true, data: settingsMap });
});

const updateSetting = asyncHandler(async (req, res) => {
    const { key, value } = req.body;
    const db = req.app.locals.db;
    db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP`).run(key, value);
    logger.info(`Configuracao atualizada: ${key} = ${value}`);
    res.json({ success: true, message: 'Configuracao atualizada' });
});

const updateMultipleSettings = asyncHandler(async (req, res) => {
    const settings = req.body;
    const db = req.app.locals.db;
    const stmt = db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP`);
    const insertMany = db.transaction((items) => {
        for (const [key, value] of Object.entries(items)) {
            stmt.run(key, String(value));
        }
    });
    insertMany(settings);
    logger.info('Multiplas configuracoes atualizadas');
    res.json({ success: true, message: 'Configuracoes atualizadas' });
});

module.exports = { getSettings, updateSetting, updateMultipleSettings };
