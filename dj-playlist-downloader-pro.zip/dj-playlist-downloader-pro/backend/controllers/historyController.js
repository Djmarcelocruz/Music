/**
 * Controller de historico
 */

const { logger } = require('../utils/logger');
const { asyncHandler } = require('../utils/errorHandler');
const { validatePagination } = require('../utils/validators');

const addToHistory = asyncHandler(async (req, res) => {
    const { track_id } = req.body;
    const db = req.app.locals.db;
    db.prepare('INSERT INTO history (track_id) VALUES (?)').run(track_id);
    logger.info(`Adicionado ao historico: ${track_id}`);
    res.json({ success: true, message: 'Registrado no historico' });
});

const getHistory = asyncHandler(async (req, res) => {
    const { page, limit, offset } = validatePagination(req.query.page, req.query.limit);
    const db = req.app.locals.db;
    const total = db.prepare('SELECT COUNT(*) as total FROM history').get().total;
    const history = db.prepare(`
        SELECT h.*, t.title, t.artist, t.album, t.cover_url, t.duration
        FROM history h
        JOIN tracks t ON h.track_id = t.id
        ORDER BY h.played_at DESC
        LIMIT ? OFFSET ?
    `).all(limit, offset);

    const grouped = history.reduce((acc, item) => {
        const date = item.played_at.split(' ')[0];
        if (!acc[date]) acc[date] = [];
        acc[date].push(item);
        return acc;
    }, {});

    res.json({
        success: true,
        data: Object.entries(grouped).map(([date, items]) => ({ date, items })),
        pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    });
});

const clearHistory = asyncHandler(async (req, res) => {
    const db = req.app.locals.db;
    db.prepare('DELETE FROM history').run();
    logger.info('Historico limpo');
    res.json({ success: true, message: 'Historico limpo' });
});

module.exports = { addToHistory, getHistory, clearHistory };
