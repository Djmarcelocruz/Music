/**
 * Controller de faixas/musicas
 */

const { v4: uuidv4 } = require('uuid');
const { logger } = require('../utils/logger');
const { AppError, asyncHandler } = require('../utils/errorHandler');
const { validateRequired, validateDuration, sanitizeString, validatePagination } = require('../utils/validators');

const searchTracks = asyncHandler(async (req, res) => {
    const { q, artist, album, genre, category } = req.query;
    const { page, limit, offset } = validatePagination(req.query.page, req.query.limit);
    const db = req.app.locals.db;
    let query = 'SELECT * FROM tracks WHERE 1=1';
    const params = [];

    if (q) {
        query += ` AND (title LIKE ? OR artist LIKE ? OR album LIKE ?)`;
        const term = `%${sanitizeString(q)}%`;
        params.push(term, term, term);
    }
    if (artist) { query += ` AND artist LIKE ?`; params.push(`%${sanitizeString(artist)}%`); }
    if (album) { query += ` AND album LIKE ?`; params.push(`%${sanitizeString(album)}%`); }
    if (genre) { query += ` AND genre = ?`; params.push(genre); }
    if (category) { query += ` AND category = ?`; params.push(category); }

    const countStmt = db.prepare(`SELECT COUNT(*) as total FROM (${query})`);
    const { total } = countStmt.get(...params);

    query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const tracks = db.prepare(query).all(...params);
    logger.info(`Busca: "${q || 'todos'}", ${tracks.length} resultados`);

    res.json({ success: true, data: tracks, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } });
});

const getTrackById = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const db = req.app.locals.db;
    const track = db.prepare('SELECT * FROM tracks WHERE id = ?').get(id);
    if (!track) throw new AppError('Musica nao encontrada', 404, 'NOT_FOUND');
    res.json({ success: true, data: track });
});

const createTrack = asyncHandler(async (req, res) => {
    const { title, artist, album, duration, cover_url, bpm, key, genre, category } = req.body;
    const db = req.app.locals.db;

    const track = {
        id: uuidv4(),
        title: validateRequired(title, 'Titulo'),
        artist: validateRequired(artist, 'Artista'),
        album: sanitizeString(album || ''),
        duration: validateDuration(duration || 0),
        cover_url: cover_url || null,
        bpm: bpm ? parseInt(bpm) : null,
        key: key || null,
        genre: genre || null,
        category: category || null
    };

    db.prepare(`INSERT INTO tracks (id, title, artist, album, duration, cover_url, bpm, key, genre, category)
        VALUES (@id, @title, @artist, @album, @duration, @cover_url, @bpm, @key, @genre, @category)`).run(track);

    logger.info(`Track criada: ${track.title} - ${track.artist}`);
    res.status(201).json({ success: true, data: track, message: 'Musica adicionada com sucesso' });
});

const updateTrack = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const db = req.app.locals.db;

    if (!db.prepare('SELECT id FROM tracks WHERE id = ?').get(id)) {
        throw new AppError('Musica nao encontrada', 404, 'NOT_FOUND');
    }

    const allowed = ['title', 'artist', 'album', 'duration', 'cover_url', 'bpm', 'key', 'genre', 'category'];
    const setClauses = [];
    const values = [];

    for (const field of allowed) {
        if (updates[field] !== undefined) {
            setClauses.push(`${field} = ?`);
            values.push(field === 'title' || field === 'artist' ? validateRequired(updates[field], field) : updates[field]);
        }
    }

    if (setClauses.length === 0) throw new AppError('Nenhum campo para atualizar', 400, 'VALIDATION_ERROR');

    values.push(id);
    db.prepare(`UPDATE tracks SET ${setClauses.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(...values);
    logger.info(`Track atualizada: ${id}`);
    res.json({ success: true, message: 'Musica atualizada com sucesso' });
});

const deleteTrack = asyncHandler(async (req, res) => {
    const { id } = req.params;
    const db = req.app.locals.db;
    const result = db.prepare('DELETE FROM tracks WHERE id = ?').run(id);
    if (result.changes === 0) throw new AppError('Musica nao encontrada', 404, 'NOT_FOUND');
    logger.info(`Track removida: ${id}`);
    res.json({ success: true, message: 'Musica removida com sucesso' });
});

const getLibraryStats = asyncHandler(async (req, res) => {
    const db = req.app.locals.db;
    const stats = db.prepare(`SELECT COUNT(*) as total_tracks, COUNT(DISTINCT artist) as total_artists,
        COUNT(DISTINCT album) as total_albums, COUNT(DISTINCT genre) as total_genres, SUM(duration) as total_duration FROM tracks`).get();
    const recentTracks = db.prepare('SELECT * FROM tracks ORDER BY created_at DESC LIMIT 5').all();
    res.json({ success: true, data: { ...stats, recent_tracks: recentTracks } });
});

module.exports = { searchTracks, getTrackById, createTrack, updateTrack, deleteTrack, getLibraryStats };
