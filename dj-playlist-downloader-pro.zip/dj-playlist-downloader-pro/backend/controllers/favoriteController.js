/**
 * Controller de favoritos
 */

const { logger } = require('../utils/logger');
const { AppError, asyncHandler } = require('../utils/errorHandler');

const getFavorites = asyncHandler(async (req, res) => {
    const db = req.app.locals.db;
    const favorites = db.prepare(`
        SELECT t.*, f.added_at as favorited_at
        FROM favorites f
        JOIN tracks t ON f.track_id = t.id
        ORDER BY f.added_at DESC
    `).all();
    res.json({ success: true, data: favorites, count: favorites.length });
});

const addFavorite = asyncHandler(async (req, res) => {
    const { track_id } = req.body;
    const db = req.app.locals.db;
    if (!db.prepare('SELECT id FROM tracks WHERE id = ?').get(track_id)) {
        throw new AppError('Musica nao encontrada', 404, 'NOT_FOUND');
    }
    db.prepare('INSERT OR IGNORE INTO favorites (track_id) VALUES (?)').run(track_id);
    logger.info(`Adicionado aos favoritos: ${track_id}`);
    res.json({ success: true, message: 'Adicionado aos favoritos' });
});

const removeFavorite = asyncHandler(async (req, res) => {
    const { trackId } = req.params;
    const db = req.app.locals.db;
    db.prepare('DELETE FROM favorites WHERE track_id = ?').run(trackId);
    logger.info(`Removido dos favoritos: ${trackId}`);
    res.json({ success: true, message: 'Removido dos favoritos' });
});

const checkFavorite = asyncHandler(async (req, res) => {
    const { trackId } = req.params;
    const db = req.app.locals.db;
    const result = db.prepare('SELECT 1 FROM favorites WHERE track_id = ?').get(trackId);
    res.json({ success: true, isFavorite: !!result });
});

module.exports = { getFavorites, addFavorite, removeFavorite, checkFavorite };
