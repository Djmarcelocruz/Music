/**
 * DJ Playlist Downloader PRO - Frontend Application
 * Aplicacao PWA completa para gerenciamento de playlists
 */

// ============================================
// CONFIGURACAO E ESTADO GLOBAL
// ============================================

const CONFIG = {
    API_BASE: '',
    DEFAULT_PAGE: 'dashboard',
    DEBOUNCE_DELAY: 300,
    TOAST_DURATION: 3000
};

const state = {
    currentPage: CONFIG.DEFAULT_PAGE,
    currentTrack: null,
    isPlaying: false,
    queue: [],
    queueIndex: 0,
    volume: 0.8,
    isShuffle: false,
    isRepeat: false,
    searchQuery: '',
    libraryView: 'grid',
    settings: {},
    favorites: new Set()
};

// ============================================
// UTILITARIOS
// ============================================

/**
 * Formata duracao em segundos para MM:SS
 */
function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

/**
 * Formata data para exibicao
 */
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pt-BR', {
        day: '2-digit', month: 'short', year: 'numeric'
    });
}

/**
 * Debounce para busca
 */
function debounce(fn, delay) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => fn(...args), delay);
    };
}

/**
 * Mostra toast notification
 */
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.backgroundColor = type === 'error' ? 'var(--error)' : 'var(--accent)';
    container.appendChild(toast);
    setTimeout(() => toast.remove(), CONFIG.TOAST_DURATION + 300);
}

/**
 * Requisicao API com tratamento de erro
 */
async function api(endpoint, options = {}) {
    try {
        const url = `${CONFIG.API_BASE}/api${endpoint}`;
        const response = await fetch(url, {
            headers: { 'Content-Type': 'application/json', ...options.headers },
            ...options
        });
        const data = await response.json();
        if (!data.success) throw new Error(data.error?.message || 'Erro desconhecido');
        return data;
    } catch (error) {
        console.error('API Error:', error);
        showToast(error.message, 'error');
        throw error;
    }
}

// ============================================
// NAVEGACAO E ROTAS
// ============================================

/**
 * Navega para uma pagina
 */
function navigateTo(page) {
    state.currentPage = page;

    // Atualiza navegacao
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });

    // Mostra pagina
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const targetPage = document.getElementById(`page-${page}`);
    if (targetPage) targetPage.classList.add('active');

    // Atualiza URL
    window.location.hash = page;

    // Carrega dados da pagina
    loadPageData(page);

    // Fecha sidebar no mobile
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');

    // Scroll to top
    document.getElementById('pageContainer').scrollTop = 0;
}

/**
 * Carrega dados especificos da pagina
 */
async function loadPageData(page) {
    switch (page) {
        case 'dashboard':
            await loadDashboard();
            break;
        case 'library':
            await loadLibrary();
            break;
        case 'playlists':
            await loadPlaylists();
            break;
        case 'favorites':
            await loadFavorites();
            break;
        case 'history':
            await loadHistory();
            break;
        case 'search':
            // Search carrega sob demanda
            break;
    }
}

// ============================================
// DASHBOARD
// ============================================

async function loadDashboard() {
    try {
        const { data } = await api('/tracks/stats');

        document.getElementById('statTracks').textContent = data.total_tracks || 0;
        document.getElementById('statArtists').textContent = data.total_artists || 0;
        document.getElementById('statAlbums').textContent = data.total_albums || 0;
        document.getElementById('statDuration').textContent =
            `${Math.floor((data.total_duration || 0) / 3600)}h`;

        renderTrackGrid('recentTracks', data.recent_tracks || []);
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
    }
}

// ============================================
// BIBLIOTECA
// ============================================

async function loadLibrary() {
    try {
        const { data } = await api('/tracks/search?limit=50');
        renderLibrary(data);
    } catch (error) {
        console.error('Erro ao carregar biblioteca:', error);
    }
}

function renderLibrary(tracks) {
    const container = document.getElementById('libraryContent');
    if (!tracks.length) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-music"></i>
                <p>Sua biblioteca esta vazia</p>
                <button class="btn-primary" onclick="showAddTrackModal()" style="margin-top:16px">
                    <i class="fas fa-plus"></i> Adicionar musica
                </button>
            </div>
        `;
        return;
    }

    if (state.libraryView === 'grid') {
        container.innerHTML = `<div class="track-grid" id="libraryGrid"></div>`;
        renderTrackGrid('libraryGrid', tracks);
    } else {
        container.innerHTML = `<div class="track-list" id="libraryList"></div>`;
        renderTrackList('libraryList', tracks);
    }
}

// ============================================
// PLAYLISTS
// ============================================

async function loadPlaylists() {
    try {
        const { data } = await api('/playlists');
        renderPlaylists(data);
    } catch (error) {
        console.error('Erro ao carregar playlists:', error);
    }
}

function renderPlaylists(playlists) {
    const container = document.getElementById('playlistGrid');
    if (!playlists.length) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1/-1;">
                <i class="fas fa-list"></i>
                <p>Nenhuma playlist criada</p>
            </div>
        `;
        return;
    }

    container.innerHTML = playlists.map(playlist => `
        <div class="playlist-card" onclick="openPlaylist('${playlist.id}')">
            <div class="playlist-cover">
                <i class="fas fa-music"></i>
            </div>
            <div class="playlist-title">${escapeHtml(playlist.name)}</div>
            <div class="playlist-desc">${escapeHtml(playlist.description || 'Sem descricao')}</div>
            <div class="playlist-count">${playlist.track_count} musicas</div>
        </div>
    `).join('');
}

// ============================================
// FAVORITOS
// ============================================

async function loadFavorites() {
    try {
        const { data } = await api('/favorites');
        const container = document.getElementById('favoritesContent');
        if (!data.length) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-heart"></i>
                    <p>Nenhuma musica favoritada</p>
                </div>
            `;
            return;
        }
        container.innerHTML = `<div class="track-grid" id="favoritesGrid"></div>`;
        renderTrackGrid('favoritesGrid', data);
    } catch (error) {
        console.error('Erro ao carregar favoritos:', error);
    }
}

// ============================================
// HISTORICO
// ============================================

async function loadHistory() {
    try {
        const { data } = await api('/history');
        renderHistory(data);
    } catch (error) {
        console.error('Erro ao carregar historico:', error);
    }
}

function renderHistory(groups) {
    const container = document.getElementById('historyContent');
    if (!groups.length) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-history"></i>
                <p>Seu historico esta vazio</p>
            </div>
        `;
        return;
    }

    container.innerHTML = groups.map(group => `
        <div class="history-group">
            <div class="history-date">${formatDate(group.date)}</div>
            <div class="track-list">
                ${group.items.map((item, index) => `
                    <div class="track-list-item" onclick="playTrack('${item.track_id}')">
                        <span class="track-number">${index + 1}</span>
                        <div class="track-img">
                            ${item.cover_url ? `<img src="${item.cover_url}" alt="">` : '<i class="fas fa-music"></i>'}
                        </div>
                        <div class="track-info">
                            <div class="title">${escapeHtml(item.title)}</div>
                            <div class="artist">${escapeHtml(item.artist)}</div>
                        </div>
                        <div class="track-album">${escapeHtml(item.album || '-')}</div>
                        <div class="track-duration">${formatDuration(item.duration)}</div>
                        <div class="track-actions">
                            <button onclick="event.stopPropagation(); toggleFavorite('${item.track_id}')">
                                <i class="${state.favorites.has(item.track_id) ? 'fas' : 'far'} fa-heart"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `).join('');
}

// ============================================
// PESQUISA
// ============================================

async function performSearch(query) {
    if (!query.trim()) {
        document.getElementById('searchResults').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <p>Digite para pesquisar</p>
            </div>
        `;
        return;
    }

    try {
        const { data } = await api(`/tracks/search?q=${encodeURIComponent(query)}&limit=50`);
        renderSearchResults(data);
    } catch (error) {
        console.error('Erro na pesquisa:', error);
    }
}

function renderSearchResults(tracks) {
    const container = document.getElementById('searchResults');
    if (!tracks.length) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <p>Nenhum resultado encontrado</p>
            </div>
        `;
        return;
    }

    container.innerHTML = `<div class="track-grid" id="searchGrid"></div>`;
    renderTrackGrid('searchGrid', tracks);
}

// ============================================
// RENDERIZACAO DE TRACKS
// ============================================

function renderTrackGrid(containerId, tracks) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = tracks.map(track => `
        <div class="track-card" data-id="${track.id}">
            <div class="track-cover">
                ${track.cover_url
                    ? `<img src="${track.cover_url}" alt="${escapeHtml(track.title)}">`
                    : '<i class="fas fa-music"></i>'
                }
                <button class="track-play-btn" onclick="event.stopPropagation(); playTrack('${track.id}')">
                    <i class="fas fa-play"></i>
                </button>
            </div>
            <div class="track-title">${escapeHtml(track.title)}</div>
            <div class="track-artist">${escapeHtml(track.artist)}</div>
            <div class="track-meta">${formatDuration(track.duration)}</div>
        </div>
    `).join('');

    // Adiciona click nos cards
    container.querySelectorAll('.track-card').forEach(card => {
        card.addEventListener('click', () => {
            const trackId = card.dataset.id;
            playTrack(trackId);
        });
    });
}

function renderTrackList(containerId, tracks) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = tracks.map((track, index) => `
        <div class="track-list-item" onclick="playTrack('${track.id}')">
            <span class="track-number">${index + 1}</span>
            <div class="track-img">
                ${track.cover_url
                    ? `<img src="${track.cover_url}" alt="">`
                    : '<i class="fas fa-music"></i>'
                }
            </div>
            <div class="track-info">
                <div class="title">${escapeHtml(track.title)}</div>
                <div class="artist">${escapeHtml(track.artist)}</div>
            </div>
            <div class="track-album">${escapeHtml(track.album || '-')}</div>
            <div class="track-duration">${formatDuration(track.duration)}</div>
            <div class="track-actions">
                <button onclick="event.stopPropagation(); toggleFavorite('${track.id}')">
                    <i class="${state.favorites.has(track.id) ? 'fas' : 'far'} fa-heart"></i>
                </button>
            </div>
        </div>
    `).join('');
}

// ============================================
// PLAYER
// ============================================

async function playTrack(trackId) {
    try {
        const { data: track } = await api(`/tracks/${trackId}`);
        state.currentTrack = track;
        state.isPlaying = true;

        updatePlayerUI();
        addToHistory(trackId);

        showToast(`Tocando: ${track.title}`);
    } catch (error) {
        console.error('Erro ao tocar musica:', error);
    }
}

function updatePlayerUI() {
    const track = state.currentTrack;
    if (!track) return;

    const cover = document.getElementById('playerCover');
    const title = document.getElementById('playerTitle');
    const artist = document.getElementById('playerArtist');
    const playBtn = document.getElementById('playBtn');
    const favBtn = document.getElementById('playerFavorite');

    title.textContent = track.title;
    artist.textContent = track.artist;

    if (track.cover_url) {
        cover.innerHTML = `<img src="${track.cover_url}" alt="">`;
    } else {
        cover.innerHTML = '<i class="fas fa-music"></i>';
    }

    playBtn.innerHTML = state.isPlaying
        ? '<i class="fas fa-pause"></i>'
        : '<i class="fas fa-play"></i>';

    favBtn.innerHTML = state.favorites.has(track.id)
        ? '<i class="fas fa-heart"></i>'
        : '<i class="far fa-heart"></i>';
    favBtn.classList.toggle('active', state.favorites.has(track.id));
}

function togglePlay() {
    state.isPlaying = !state.isPlaying;
    const playBtn = document.getElementById('playBtn');
    playBtn.innerHTML = state.isPlaying
        ? '<i class="fas fa-pause"></i>'
        : '<i class="fas fa-play"></i>';
}

function playNext() {
    if (!state.queue.length) return;
    state.queueIndex = (state.queueIndex + 1) % state.queue.length;
    playTrack(state.queue[state.queueIndex].id);
}

function playPrevious() {
    if (!state.queue.length) return;
    state.queueIndex = (state.queueIndex - 1 + state.queue.length) % state.queue.length;
    playTrack(state.queue[state.queueIndex].id);
}

function toggleShuffle() {
    state.isShuffle = !state.isShuffle;
    document.getElementById('shuffleBtn').style.color =
        state.isShuffle ? 'var(--accent)' : 'var(--text-secondary)';
}

function toggleRepeat() {
    state.isRepeat = !state.isRepeat;
    document.getElementById('repeatBtn').style.color =
        state.isRepeat ? 'var(--accent)' : 'var(--text-secondary)';
}

async function toggleFavorite(trackId) {
    const id = trackId || state.currentTrack?.id;
    if (!id) return;

    try {
        if (state.favorites.has(id)) {
            await api(`/favorites/${id}`, { method: 'DELETE' });
            state.favorites.delete(id);
            showToast('Removido dos favoritos');
        } else {
            await api('/favorites', {
                method: 'POST',
                body: JSON.stringify({ track_id: id })
            });
            state.favorites.add(id);
            showToast('Adicionado aos favoritos');
        }

        // Atualiza UI
        updatePlayerUI();
        if (state.currentPage === 'favorites') loadFavorites();
    } catch (error) {
        console.error('Erro ao alternar favorito:', error);
    }
}

async function addToHistory(trackId) {
    try {
        await api('/history', {
            method: 'POST',
            body: JSON.stringify({ track_id: trackId })
        });
    } catch (error) {
        console.error('Erro ao registrar historico:', error);
    }
}

// ============================================
// MODAIS
// ============================================

function showModal(title, content) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    document.getElementById('modalOverlay').classList.add('active');
}

function hideModal() {
    document.getElementById('modalOverlay').classList.remove('active');
}

function showAddTrackModal() {
    showModal('Adicionar Musica', `
        <form id="addTrackForm">
            <div class="form-group">
                <label>Titulo</label>
                <input type="text" name="title" required placeholder="Nome da musica">
            </div>
            <div class="form-group">
                <label>Artista</label>
                <input type="text" name="artist" required placeholder="Nome do artista">
            </div>
            <div class="form-group">
                <label>Album</label>
                <input type="text" name="album" placeholder="Nome do album">
            </div>
            <div class="form-group">
                <label>Duracao (segundos)</label>
                <input type="number" name="duration" placeholder="180">
            </div>
            <div class="form-group">
                <label>URL da Capa</label>
                <input type="url" name="cover_url" placeholder="https://...">
            </div>
            <div class="form-group">
                <label>Genero</label>
                <input type="text" name="genre" placeholder="Ex: House, Techno">
            </div>
            <button type="submit" class="btn-primary" style="width:100%;margin-top:8px">
                <i class="fas fa-plus"></i> Adicionar
            </button>
        </form>
    `);

    document.getElementById('addTrackForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        try {
            await api('/tracks', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            showToast('Musica adicionada com sucesso');
            hideModal();
            if (state.currentPage === 'library') loadLibrary();
            if (state.currentPage === 'dashboard') loadDashboard();
        } catch (error) {
            console.error('Erro ao adicionar musica:', error);
        }
    });
}

function showCreatePlaylistModal() {
    showModal('Nova Playlist', `
        <form id="createPlaylistForm">
            <div class="form-group">
                <label>Nome</label>
                <input type="text" name="name" required placeholder="Nome da playlist">
            </div>
            <div class="form-group">
                <label>Descricao</label>
                <textarea name="description" rows="3" placeholder="Descricao opcional"></textarea>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;margin-top:8px">
                <i class="fas fa-plus"></i> Criar Playlist
            </button>
        </form>
    `);

    document.getElementById('createPlaylistForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        try {
            await api('/playlists', {
                method: 'POST',
                body: JSON.stringify(data)
            });
            showToast('Playlist criada com sucesso');
            hideModal();
            if (state.currentPage === 'playlists') loadPlaylists();
        } catch (error) {
            console.error('Erro ao criar playlist:', error);
        }
    });
}

// ============================================
// CONFIGURACOES
// ============================================

async function loadSettings() {
    try {
        const { data } = await api('/settings');
        state.settings = data;

        // Aplica tema
        if (data.theme) {
            document.documentElement.setAttribute('data-theme', data.theme === 'system'
                ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
                : data.theme
            );
        }

        // Preenche formularios
        const themeSelect = document.getElementById('themeSetting');
        if (themeSelect) themeSelect.value = data.theme || 'dark';

        const langSelect = document.getElementById('languageSetting');
        if (langSelect) langSelect.value = data.language || 'pt-BR';

        const autoOrganize = document.getElementById('autoOrganize');
        if (autoOrganize) autoOrganize.checked = data.auto_organize === 'true';
    } catch (error) {
        console.error('Erro ao carregar configuracoes:', error);
    }
}

async function saveSetting(key, value) {
    try {
        await api('/settings', {
            method: 'PUT',
            body: JSON.stringify({ key, value: String(value) })
        });
        state.settings[key] = String(value);
        showToast('Configuracao salva');
    } catch (error) {
        console.error('Erro ao salvar configuracao:', error);
    }
}

// ============================================
// UTILITARIOS HTML
// ============================================

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// EVENT LISTENERS
// ============================================

function initEventListeners() {
    // Navegacao
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo(item.dataset.page);
        });
    });

    // Menu toggle (mobile)
    document.getElementById('menuToggle').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('open');
        document.getElementById('sidebarOverlay').classList.toggle('active');
    });

    // Overlay
    document.getElementById('sidebarOverlay').addEventListener('click', () => {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('active');
    });

    // Fechar sidebar mobile
    document.getElementById('sidebarClose').addEventListener('click', () => {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('active');
    });

    // Busca global
    const searchInput = document.getElementById('globalSearch');
    const searchClear = document.getElementById('searchClear');

    searchInput.addEventListener('input', debounce((e) => {
        const query = e.target.value;
        searchClear.classList.toggle('visible', query.length > 0);

        if (state.currentPage !== 'search') {
            navigateTo('search');
        }
        performSearch(query);
    }, CONFIG.DEBOUNCE_DELAY));

    searchClear.addEventListener('click', () => {
        searchInput.value = '';
        searchClear.classList.remove('visible');
        if (state.currentPage === 'search') {
            document.getElementById('searchResults').innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <p>Digite para pesquisar</p>
                </div>
            `;
        }
    });

    // Filtros de busca
    document.querySelectorAll('.filter-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
        });
    });

    // Player controls
    document.getElementById('playBtn').addEventListener('click', togglePlay);
    document.getElementById('nextBtn').addEventListener('click', playNext);
    document.getElementById('prevBtn').addEventListener('click', playPrevious);
    document.getElementById('shuffleBtn').addEventListener('click', toggleShuffle);
    document.getElementById('repeatBtn').addEventListener('click', toggleRepeat);
    document.getElementById('playerFavorite').addEventListener('click', () => toggleFavorite());

    // Volume
    document.getElementById('volumeBar').addEventListener('click', (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        state.volume = Math.max(0, Math.min(1, percent));
        document.getElementById('volumeFill').style.width = `${state.volume * 100}%`;
    });

    // Progress bar
    document.getElementById('progressBar').addEventListener('click', (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        document.getElementById('progressFill').style.width = `${percent * 100}%`;
        document.getElementById('progressHandle').style.left = `${percent * 100}%`;
    });

    // View toggle (library)
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            state.libraryView = btn.dataset.view;
            if (state.currentPage === 'library') loadLibrary();
        });
    });

    // Botao adicionar musica
    document.getElementById('addTrackBtn')?.addEventListener('click', showAddTrackModal);

    // Botao criar playlist
    document.getElementById('createPlaylistBtn')?.addEventListener('click', showCreatePlaylistModal);

    // Botao limpar historico
    document.getElementById('clearHistoryBtn')?.addEventListener('click', async () => {
        if (confirm('Tem certeza que deseja limpar o historico?')) {
            try {
                await api('/history', { method: 'DELETE' });
                showToast('Historico limpo');
                loadHistory();
            } catch (error) {
                console.error('Erro ao limpar historico:', error);
            }
        }
    });

    // Tema
    document.getElementById('themeToggle').addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'dark';
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        document.querySelector('#themeToggle i').className = next === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
        saveSetting('theme', next);
    });

    // Configuracoes
    document.getElementById('themeSetting')?.addEventListener('change', (e) => {
        const theme = e.target.value;
        document.documentElement.setAttribute('data-theme',
            theme === 'system' ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : theme
        );
        saveSetting('theme', theme);
    });

    document.getElementById('languageSetting')?.addEventListener('change', (e) => {
        saveSetting('language', e.target.value);
    });

    document.getElementById('autoOrganize')?.addEventListener('change', (e) => {
        saveSetting('auto_organize', e.target.checked);
    });

    // Fechar modal
    document.getElementById('modalClose').addEventListener('click', hideModal);
    document.getElementById('modalOverlay').addEventListener('click', (e) => {
        if (e.target === document.getElementById('modalOverlay')) hideModal();
    });

    // Teclas de atalho
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

        switch (e.code) {
            case 'Space':
                e.preventDefault();
                togglePlay();
                break;
            case 'ArrowRight':
                if (e.ctrlKey) playNext();
                break;
            case 'ArrowLeft':
                if (e.ctrlKey) playPrevious();
                break;
            case 'KeyF':
                if (state.currentTrack) toggleFavorite();
                break;
        }
    });

    // Hash change
    window.addEventListener('hashchange', () => {
        const page = window.location.hash.slice(1) || CONFIG.DEFAULT_PAGE;
        if (page !== state.currentPage) {
            navigateTo(page);
        }
    });
}

// ============================================
// INICIALIZACAO
// ============================================

async function init() {
    console.log('🎧 DJ Playlist Downloader PRO - Inicializando...');

    // Registra Service Worker
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/service-worker.js');
            console.log('Service Worker registrado:', registration.scope);
        } catch (error) {
            console.error('Erro ao registrar Service Worker:', error);
        }
    }

    // Carrega configuracoes
    await loadSettings();

    // Carrega favoritos
    try {
        const { data } = await api('/favorites');
        state.favorites = new Set(data.map(f => f.id));
    } catch (error) {
        console.error('Erro ao carregar favoritos:', error);
    }

    // Inicializa event listeners
    initEventListeners();

    // Navega para pagina inicial
    const initialPage = window.location.hash.slice(1) || CONFIG.DEFAULT_PAGE;
    navigateTo(initialPage);

    console.log('✅ Aplicacao inicializada');
}

// Inicia quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', init);
