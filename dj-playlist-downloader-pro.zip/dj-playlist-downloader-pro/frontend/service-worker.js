/**
 * Service Worker - DJ Playlist Downloader PRO
 */

const CACHE_NAME = 'djpro-cache-v1';
const API_CACHE_NAME = 'djpro-api-cache-v1';
const STATIC_ASSETS = [
    '/', '/index.html', '/style.css', '/app.js', '/manifest.json',
    '/icons/icon-192.png', '/icons/icon-512.png'
];

self.addEventListener('install', (event) => {
    console.log('[SW] Instalando...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(STATIC_ASSETS))
            .then(() => self.skipWaiting())
            .catch(err => console.error('[SW] Erro no install:', err))
    );
});

self.addEventListener('activate', (event) => {
    console.log('[SW] Ativando...');
    event.waitUntil(
        caches.keys()
            .then(cacheNames => Promise.all(
                cacheNames.filter(name => name !== CACHE_NAME && name !== API_CACHE_NAME)
                    .map(name => caches.delete(name))
            ))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    if (url.pathname.startsWith('/api/')) {
        event.respondWith(networkFirstStrategy(request));
        return;
    }

    if (request.destination === 'style' || request.destination === 'script' ||
        request.destination === 'image' || request.destination === 'font') {
        event.respondWith(cacheFirstStrategy(request));
        return;
    }

    event.respondWith(networkFirstStrategy(request));
});

async function cacheFirstStrategy(request) {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        return new Response('Offline - recurso nao disponivel', { status: 503 });
    }
}

async function networkFirstStrategy(request) {
    try {
        const networkResponse = await fetch(request);
        if (networkResponse.ok && request.method === 'GET') {
            const cache = await caches.open(request.url.includes('/api/') ? API_CACHE_NAME : CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }
        return networkResponse;
    } catch (error) {
        const cached = await caches.match(request);
        if (cached) return cached;
        if (request.url.includes('/api/')) {
            return new Response(
                JSON.stringify({ success: false, offline: true, message: 'Voce esta offline.' }),
                { status: 200, headers: { 'Content-Type': 'application/json' } }
            );
        }
        return new Response('Offline', { status: 503 });
    }
}

self.addEventListener('sync', (event) => {
    if (event.tag === 'sync-favorites') {
        event.waitUntil(console.log('[SW] Sincronizando favoritos...'));
    }
});

self.addEventListener('push', (event) => {
    const data = event.data?.json() || {};
    event.waitUntil(
        self.registration.showNotification(data.title || 'DJ Playlist Downloader PRO', {
            body: data.body || 'Nova atualizacao disponivel',
            icon: '/icons/icon-192.png',
            badge: '/icons/icon-72.png',
            tag: data.tag || 'default'
        })
    );
});
